Intro to Augmented Reality on the Web: using WebXR and Three.js
=================

Udemy course (with a discount): [https://www.udemy.com/course/intro-webxr/?couponCode=312E949E5142F90C8E68](https://www.udemy.com/course/intro-webxr/?couponCode=312E949E5142F90C8E68)


### Credits

* [Space Model](https://github.com/immersive-web/webxr-samples/tree/main/media/gltf/space)
* [Three.js cone sample](https://threejs.org/examples/?q=webxr#webxr_ar_cones)
